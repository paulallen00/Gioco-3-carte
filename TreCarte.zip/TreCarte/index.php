<html>
	<head>
		<title></title>
		<link href="stile.css" rel="stylesheet" type="text/css">
		<script>
			function f(t, s) {
				if (t == "uno") {
					x = document.getElementById("uno").style.zIndex = 1;
					x_c = document.getElementById("one");
					x_c.style.zIndex = 0;
					x_c.onclick = "";
					x_c = document.getElementById("two");
					x_c.onclick = "";
					x_c = document.getElementById("three");
					x_c.onclick = "";
				}
				if (t == "due") { 
					x = document.getElementById("due").style.zIndex = 1;
					x_c = document.getElementById("two");
					x_c.style.zIndex = 0;
					x_c.onclick = "";
					x_c = document.getElementById("one");
					x_c.onclick = "";
					x_c = document.getElementById("three");
					x_c.onclick = "";
				}
				if (t == "tre") { 
					x = document.getElementById("tre").style.zIndex = 1;
					x_c = document.getElementById("three");
					x_c.style.zIndex = 0;
					x_c.onclick = "";
					x_c = document.getElementById("one");
					x_c.onclick = "";
					x_c = document.getElementById("two");
					x_c.onclick = "";
				}
				let e = document.getElementById("esito");
				if (s == "1.jpg") {
					e.innerHTML="HAI VINTO!";
				} else {
					e.innerHTML="HAI PERSO!";
				}
				document.getElementById("fine").innerHTML = "<a href='index.php'>NUOVA PARTITA</a>";
			}
		</script>
	</head>
	<body>
		<?php
			$a = rand(1,3);
			$a .= ".jpg";
			do {
				$b = rand(1,3);
				$b .= ".jpg";
				$c = rand(1,3);
				$c .= ".jpg";
			} while ($a == $b || $a == $c || $b == $c);
			echo "<div id='uno'><img src='$a'></div>";
			echo "<div id='due'><img src='$b'></div>";
			echo "<div id='tre'><img src='$c'></div>";

			echo "<div id='one' onclick='f(\"uno\",\"$a\")'></div>";
			echo "<div id='two' onclick='f(\"due\",\"$b\")'></div>";
			echo "<div id='three' onclick='f(\"tre\",\"$c\")'></div>";
		?>
		<div id="esito"></div>		
		<div id="fine"></div>
	</body>
</html>


